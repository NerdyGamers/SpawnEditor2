/*
 $Id: UOMapCtl.h,v 1.8 2003/05/14 02:54:56 pesterle Exp $

 **********************************************************************
 * Copyright (C) Philip A. Esterle 2000-2003
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 * 
 **********************************************************************

*/

#if !defined(AFX_UOMAPCTL_H__D7CB6A56_E446_47A4_908A_E5A4F2A05BA9__INCLUDED_)
#define AFX_UOMAPCTL_H__D7CB6A56_E446_47A4_908A_E5A4F2A05BA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <comcat.h>
#include <objsafe.h>

// UOMapCtl.h : Declaration of the CUOMapCtrl ActiveX Control class.

#define VERFILE_MAP0 0x00
#define VERFILE_STAIDX0 0x01
#define VERFILE_STATICS0 0x02
#define VERFILE_ARTIDX 0x03
#define VERFILE_ART 0x04
#define VERFILE_ANIMIDX 0x05
#define VERFILE_ANIM 0x06
#define VERFILE_SOUNDIDX 0x07
#define VERFILE_SOUND 0x08
#define VERFILE_TEXIDX 0x09
#define VERFILE_TEXMAPS 0x0a
#define VERFILE_GUMPIDX 0x0b
#define VERFILE_GUMPART 0x0c
#define VERFILE_MULTIIDX 0x0d
#define VERFILE_MULTI 0x0e
#define VERFILE_SKILLSIDX 0x0f
#define VERFILE_SKILLS 0x10
#define VERFILE_LIGHTIDX 0x11 // ???
#define VERFILE_LIGHT 0x12 // ???
#define VERFILE_TILEDATA	0x1e
#define VERFILE_ANIMDATA 0x1f
#define VERFILE_HUES 0x20
// don't know about these...so we'll assign them numbers for now
#define VERFILE_ANIMINFO 0x21
#define VERFILE_FONTS 0x22
#define VERFILE_RADARCOL 0x23
#define VERFILE_VERDATA 0x24
#define VERFILE_MAP2 0x25
#define VERFILE_STAIDX2 0x26
#define VERFILE_STATICS2 0x27
#define VERFILE_ANIM2 0x28
#define VERFILE_ANIMIDX2 0x29

#define VERFILE_MAP3 0x30
#define VERFILE_STAIDX3 0x31
#define VERFILE_STATICS3 0x32
#define VERFILE_ANIM3 0x33
#define VERFILE_ANIMIDX3 0x34
#define VERFILE_MAPDIF3 0x35
#define VERFILE_MAPDIFL3 0x36
#define VERFILE_STADIF3 0x37
#define VERFILE_STADIFI3 0x38
#define VERFILE_STADIFL3 0x39

#define VERFILE_MAPDIF0 0x40
#define VERFILE_MAPDIF1 0x41
#define VERFILE_MAPDIF2 0x42
#define VERFILE_MAPDIFL0 0x43
#define VERFILE_MAPDIFL1 0x44
#define VERFILE_MAPDIFL2 0x45
#define VERFILE_STADIF0 0x46
#define VERFILE_STADIF1 0x47
#define VERFILE_STADIF2 0x48
#define VERFILE_STADIFI0 0x49
#define VERFILE_STADIFI1 0x4a
#define VERFILE_STADIFI2 0x4b
#define VERFILE_STADIFL0 0x4c
#define VERFILE_STADIFL1 0x4d
#define VERFILE_STADIFL2 0x4e
#define VERFILE_ENDOFTABLE 0x4f

HRESULT CreateComponentCategory(CATID catid, WCHAR* catDescription);
HRESULT RegisterCLSIDInCategory(REFCLSID clsid, CATID catid);
HRESULT UnRegisterCLSIDInCategory(REFCLSID clsid, CATID catid);

class CDrawObject : public CObject
{
public:
	CDrawObject();
	CPoint m_pt;
	BYTE m_bDrawType;
	BYTE m_bSize;
	DWORD m_dwColor;
};

class CDrawRect : public CObject
{
public:
	CDrawRect();
	CRect m_rect;
	BYTE m_bDrawMode;
	DWORD m_dwColor;
};

struct PatchHash
{
	DWORD dwIndex;
	DWORD dwLookup;
};

/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl : See UOMapCtl.cpp for implementation.
class CUOMapCtrl : public COleControl
{
	DECLARE_DYNCREATE(CUOMapCtrl)

// Constructor
public:
	CUOMapCtrl();

	enum
	{
		DRAW_NONE,
		DRAW_PLUS,
		DRAW_SQUARE,
		DRAW_DIAMOND,
		DRAW_DOT,
		DRAW_CIRCLE,
		DRAW_TRIANGLE,

		DRAW_TYPE_QTY
	} DRAW_TYPE;
	enum
	{
		DRAW_FILL,
		DRAW_BLEND,
		DRAW_OUTLINE,

		DRAW_MODE_QTY
	} DRAW_MODE;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUOMapCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual DWORD GetControlFlags();
	//}}AFX_VIRTUAL

// Implementation
protected:
	void LoadPatchHash(CString sFile, CPtrArray& array);
	void CleanHashArray(CPtrArray& array);
	void InsertHash(CPtrArray& array, DWORD lookup, DWORD index);
	DWORD FindPatch(CPtrArray& array, DWORD lookup);
	void InitializeMulPaths();
	CObArray m_aDrawObjects;
	CObArray m_aDrawRects;
	CRect m_rcSize;
	bool m_bIsValid;
	void SetInvalid();
	CByteArray m_bMapArray;
	BOOL m_bDrawStatics;
	DWORD ScaleColor(WORD wColor);
	CString m_csUOPath;
	void LoadRadarcol();
	DWORD * m_dwColorMap;
	void RedrawMap(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	short m_xCenter;
	short m_yCenter;
	short m_zoomLevel;
	~CUOMapCtrl();
	CPoint m_ptMouse;
	CStringArray m_saMulPaths;

	int m_maxX;
	int m_maxY;

	CPtrArray m_aMap0Hash;
	CPtrArray m_aStatic0Hash;
	CPtrArray m_aMap1Hash;
	CPtrArray m_aStatic1Hash;
	CPtrArray m_aMap2Hash;
	CPtrArray m_aStatic2Hash;
	CPtrArray m_aMap3Hash;
	CPtrArray m_aStatic3Hash;

	short m_mulfile;

	DECLARE_OLECREATE_EX(CUOMapCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CUOMapCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CUOMapCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CUOMapCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CUOMapCtrl)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CUOMapCtrl)
	afx_msg short GetZoomLevel();
	afx_msg void SetZoomLevel(short nNewValue);
	afx_msg short GetXCenter();
	afx_msg void SetXCenter(short nNewValue);
	afx_msg short GetYCenter();
	afx_msg void SetYCenter(short nNewValue);
	afx_msg BOOL GetDrawStatics();
	afx_msg void SetDrawStatics(BOOL bNewValue);
	afx_msg short GetMapFile();
	afx_msg void SetMapFile(short nNewValue);
	afx_msg void ZoomIn();
	afx_msg void ZoomOut();
	afx_msg void SetCenter(short x, short y);
	afx_msg void Scroll(short direction, short distance);
	afx_msg void CtrlToMap(short FAR* x, short FAR* y);
	afx_msg void MapToCtrl(short FAR* x, short FAR* y);
	afx_msg void GetCenter(short FAR* x, short FAR* y);
	afx_msg short CtrlToMapX(short x);
	afx_msg short CtrlToMapY(short y);
	afx_msg short MapToCtrlX(short x);
	afx_msg short MapToCtrlY(short y);
	afx_msg short GetMapHeight(short x, short y);
	afx_msg long AddDrawObject(short x, short y, short type, short size, long color);
	afx_msg BOOL RemoveDrawObject(short x, short y, short type, short size, long color);
	afx_msg BOOL RemoveDrawObjectAt(long index);
	afx_msg void RemoveDrawObjects();
	afx_msg long AddDrawRect(short xleft, short ytop, short width, short height, short mode, long color);
	afx_msg void RemoveDrawRects();
	afx_msg BOOL RemoveDrawRectAt(long index);
	afx_msg BOOL RemoveDrawRect(short x, short y, short width, short height, short mode, long color);
	afx_msg void SetClientPath(LPCTSTR pszClientPath);
	afx_msg long GetCenterBlock();
	afx_msg BOOL SetCustomMulPath(short sFileIndex, LPCTSTR pszFilePath);
	afx_msg BSTR GetCustomMulPath(short sFileIndex);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

// Event maps
	//{{AFX_EVENT(CUOMapCtrl)
	void FireMouseDown(short Button, short Shift, OLE_XPOS_PIXELS x, OLE_YPOS_PIXELS y)
		{FireEvent(DISPID_MOUSEDOWN,EVENT_PARAM(VTS_I2  VTS_I2  VTS_XPOS_PIXELS  VTS_YPOS_PIXELS), Button, Shift, x, y);}
	void FireMouseMove(short Button, short Shift, OLE_XPOS_PIXELS x, OLE_YPOS_PIXELS y)
		{FireEvent(DISPID_MOUSEMOVE,EVENT_PARAM(VTS_I2  VTS_I2  VTS_XPOS_PIXELS  VTS_YPOS_PIXELS), Button, Shift, x, y);}
	void FireMouseUp(short Button, short Shift, OLE_XPOS_PIXELS x, OLE_YPOS_PIXELS y)
		{FireEvent(DISPID_MOUSEUP,EVENT_PARAM(VTS_I2  VTS_I2  VTS_XPOS_PIXELS  VTS_YPOS_PIXELS), Button, Shift, x, y);}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CUOMapCtrl)
	dispidZoomLevel = 1L,
	dispidXCenter = 2L,
	dispidYCenter = 3L,
	dispidDrawStatics = 4L,
	dispidMapFile = 5L,
	dispidZoomIn = 6L,
	dispidZoomOut = 7L,
	dispidSetCenter = 8L,
	dispidScroll = 9L,
	dispidCtrlToMap = 10L,
	dispidMapToCtrl = 11L,
	dispidGetCenter = 12L,
	dispidCtrlToMapX = 13L,
	dispidCtrlToMapY = 14L,
	dispidMapToCtrlX = 15L,
	dispidMapToCtrlY = 16L,
	dispidGetMapHeight = 17L,
	dispidAddDrawObject = 18L,
	dispidRemoveDrawObject = 19L,
	dispidRemoveDrawObjectAt = 20L,
	dispidRemoveDrawObjects = 21L,
	dispidAddDrawRect = 22L,
	dispidRemoveDrawRects = 23L,
	dispidRemoveDrawRectAt = 24L,
	dispidRemoveDrawRect = 25L,
	dispidSetClientPath = 26L,
	dispidGetCenterBlock = 27L,
	dispidSetCustomMulPath = 28L,
	dispidGetCustomMulPath = 29L,
	//}}AFX_DISP_ID
	};

	enum {
		SCROLL_N = 0,
		SCROLL_NE,
		SCROLL_E,
		SCROLL_SE,
		SCROLL_S,
		SCROLL_SW,
		SCROLL_W,
		SCROLL_NW
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.


#endif // !defined(AFX_UOMAPCTL_H__D7CB6A56_E446_47A4_908A_E5A4F2A05BA9__INCLUDED)

