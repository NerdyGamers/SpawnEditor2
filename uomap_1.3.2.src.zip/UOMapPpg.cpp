/*
 $Id: UOMapPpg.cpp,v 1.3 2002/05/28 19:13:01 pesterle Exp $

 **********************************************************************
 * Copyright (C) Philip A. Esterle 2000-2002
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 * 
 **********************************************************************

*/

// UOMapPpg.cpp : Implementation of the CUOMapPropPage property page class.

#include "stdafx.h"
#include "UOMap.h"
#include "UOMapPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CUOMapPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CUOMapPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CUOMapPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CUOMapPropPage, "UOMAP.UOMapPropPage.1",
	0xefc3c02c, 0xbec4, 0x43a8, 0x8c, 0x8e, 0x83, 0x9b, 0x6d, 0xc7, 0x93, 0x4e)


/////////////////////////////////////////////////////////////////////////////
// CUOMapPropPage::CUOMapPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CUOMapPropPage

BOOL CUOMapPropPage::CUOMapPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_UOMAP_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapPropPage::CUOMapPropPage - Constructor

CUOMapPropPage::CUOMapPropPage() :
	COlePropertyPage(IDD, IDS_UOMAP_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CUOMapPropPage)
	m_bDrawStatics = FALSE;
	m_xCenter = 0;
	m_yCenter = 0;
	m_sZoomLevel = 0;
	m_iMapfile = 0;
	//}}AFX_DATA_INIT

	SetHelpInfo(_T("Names to appear in the control"), _T("UOMAP.HLP"), 0);
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapPropPage::DoDataExchange - Moves data between page and properties

void CUOMapPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CUOMapPropPage)
	DDP_Check(pDX, IDC_DRAWSTATICS, m_bDrawStatics, _T("DrawStatics") );
	DDX_Check(pDX, IDC_DRAWSTATICS, m_bDrawStatics);
	DDP_Text(pDX, IDC_MAPX, m_xCenter, _T("xCenter") );
	DDX_Text(pDX, IDC_MAPX, m_xCenter);
	DDV_MinMaxInt(pDX, m_xCenter, 0, 6144);
	DDP_Text(pDX, IDC_MAPY, m_yCenter, _T("yCenter") );
	DDX_Text(pDX, IDC_MAPY, m_yCenter);
	DDV_MinMaxInt(pDX, m_yCenter, 0, 4096);
	DDP_Text(pDX, IDC_ZOOMLEVEL, m_sZoomLevel, _T("ZoomLevel") );
	DDX_Text(pDX, IDC_ZOOMLEVEL, m_sZoomLevel);
	DDP_Text(pDX, IDC_MAPFILE, m_iMapfile, _T("MapFile"));
	DDX_Text(pDX, IDC_MAPFILE, m_iMapfile);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapPropPage message handlers
