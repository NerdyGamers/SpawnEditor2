/*
 $Id: UOMapCtl.cpp,v 1.13.2.2 2003/06/03 16:17:56 pesterle Exp $

 **********************************************************************
 * Copyright (C) Philip A. Esterle 2000-2003
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 * 
 **********************************************************************

*/

// UOMapCtl.cpp : Implementation of the CUOMapCtrl ActiveX Control class.

#include "stdafx.h"
#include "UOMap.h"
#include "UOMapCtl.h"
#include "UOMapPpg.h"
#include <math.h>
#include <comcat.h>
#include <objsafe.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define UO_X_SIZE m_maxX
#define UO_Y_SIZE m_maxY
#define UO_X_CENTER (UO_X_SIZE / 2)
#define UO_Y_CENTER (UO_Y_SIZE / 2)
#define UO_X_BLOCKS (UO_X_SIZE / 8)
#define UO_Y_BLOCKS (UO_Y_SIZE / 8)
#define UO_X_CENTER_BLOCK (UO_X_CENTER / 8)
#define UO_Y_CENTER_BLOCK (UO_Y_CENTER / 8)

class MapCell
{
public:
	BYTE bColorLo;
	BYTE bColorHi;
	CHAR bAltitude;
};

class MapBlock
{
public:
	DWORD dwHeader;
	MapCell cells[64];
};

class StaticIdx
{
public:
	DWORD dwStart;
	DWORD dwLength;
	DWORD dwUnk;
};

class StaticData
{
public:
	BYTE bColorLo;
	BYTE bColorHi;
	BYTE bXoff;
	BYTE bYoff;
	CHAR bAlt;
	BYTE bJunk1;
	BYTE bJunk2;
};

CDrawObject::CDrawObject()
{
	m_pt.x = 0;
	m_pt.y = 0;
	m_bDrawType = 0;
	m_bSize = 0;
	m_dwColor = 0;
}

CDrawRect::CDrawRect()
{
	m_bDrawMode = 0;
	m_dwColor = 0;
}

IMPLEMENT_DYNCREATE(CUOMapCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CUOMapCtrl, COleControl)
	//{{AFX_MSG_MAP(CUOMapCtrl)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_EDIT, OnEdit)
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CUOMapCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CUOMapCtrl)
	DISP_PROPERTY_EX(CUOMapCtrl, "ZoomLevel", GetZoomLevel, SetZoomLevel, VT_I2)
	DISP_PROPERTY_EX(CUOMapCtrl, "xCenter", GetXCenter, SetXCenter, VT_I2)
	DISP_PROPERTY_EX(CUOMapCtrl, "yCenter", GetYCenter, SetYCenter, VT_I2)
	DISP_PROPERTY_EX(CUOMapCtrl, "DrawStatics", GetDrawStatics, SetDrawStatics, VT_BOOL)
	DISP_PROPERTY_EX(CUOMapCtrl, "MapFile", GetMapFile, SetMapFile, VT_I2)
	DISP_FUNCTION(CUOMapCtrl, "ZoomIn", ZoomIn, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CUOMapCtrl, "ZoomOut", ZoomOut, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CUOMapCtrl, "SetCenter", SetCenter, VT_EMPTY, VTS_I2 VTS_I2)
	DISP_FUNCTION(CUOMapCtrl, "Scroll", Scroll, VT_EMPTY, VTS_I2 VTS_I2)
	DISP_FUNCTION(CUOMapCtrl, "CtrlToMap", CtrlToMap, VT_EMPTY, VTS_PI2 VTS_PI2)
	DISP_FUNCTION(CUOMapCtrl, "MapToCtrl", MapToCtrl, VT_EMPTY, VTS_PI2 VTS_PI2)
	DISP_FUNCTION(CUOMapCtrl, "GetCenter", GetCenter, VT_EMPTY, VTS_PI2 VTS_PI2)
	DISP_FUNCTION(CUOMapCtrl, "CtrlToMapX", CtrlToMapX, VT_I2, VTS_I2)
	DISP_FUNCTION(CUOMapCtrl, "CtrlToMapY", CtrlToMapY, VT_I2, VTS_I2)
	DISP_FUNCTION(CUOMapCtrl, "MapToCtrlX", MapToCtrlX, VT_I2, VTS_I2)
	DISP_FUNCTION(CUOMapCtrl, "MapToCtrlY", MapToCtrlY, VT_I2, VTS_I2)
	DISP_FUNCTION(CUOMapCtrl, "GetMapHeight", GetMapHeight, VT_I2, VTS_I2 VTS_I2)
	DISP_FUNCTION(CUOMapCtrl, "AddDrawObject", AddDrawObject, VT_I4, VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I4)
	DISP_FUNCTION(CUOMapCtrl, "RemoveDrawObject", RemoveDrawObject, VT_BOOL, VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I4)
	DISP_FUNCTION(CUOMapCtrl, "RemoveDrawObjectAt", RemoveDrawObjectAt, VT_BOOL, VTS_I4)
	DISP_FUNCTION(CUOMapCtrl, "RemoveDrawObjects", RemoveDrawObjects, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CUOMapCtrl, "AddDrawRect", AddDrawRect, VT_I4, VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I4)
	DISP_FUNCTION(CUOMapCtrl, "RemoveDrawRects", RemoveDrawRects, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CUOMapCtrl, "RemoveDrawRectAt", RemoveDrawRectAt, VT_BOOL, VTS_I4)
	DISP_FUNCTION(CUOMapCtrl, "RemoveDrawRect", RemoveDrawRect, VT_BOOL, VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I4)
	DISP_FUNCTION(CUOMapCtrl, "SetClientPath", SetClientPath, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION(CUOMapCtrl, "GetCenterBlock", GetCenterBlock, VT_I4, VTS_NONE)
	DISP_FUNCTION(CUOMapCtrl, "SetCustomMulPath", SetCustomMulPath, VT_BOOL, VTS_I2 VTS_BSTR)
	DISP_FUNCTION(CUOMapCtrl, "GetCustomMulPath", GetCustomMulPath, VT_BSTR, VTS_I2)
	DISP_STOCKPROP_READYSTATE()
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CUOMapCtrl, COleControl)
	//{{AFX_EVENT_MAP(CUOMapCtrl)
	EVENT_STOCK_READYSTATECHANGE()
	EVENT_CUSTOM_ID("MouseDown", DISPID_MOUSEDOWN, FireMouseDown, VTS_I2  VTS_I2  VTS_XPOS_PIXELS  VTS_YPOS_PIXELS)
	EVENT_CUSTOM_ID("MouseMove", DISPID_MOUSEMOVE, FireMouseMove, VTS_I2  VTS_I2  VTS_XPOS_PIXELS  VTS_YPOS_PIXELS)
	EVENT_CUSTOM_ID("MouseUp", DISPID_MOUSEUP, FireMouseUp, VTS_I2  VTS_I2  VTS_XPOS_PIXELS  VTS_YPOS_PIXELS)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CUOMapCtrl, 1)
	PROPPAGEID(CUOMapPropPage::guid)
END_PROPPAGEIDS(CUOMapCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CUOMapCtrl, "UOMAP.UOMapCtrl.1",
	0x2ac21540, 0x4c63, 0x4663, 0xbf, 0x24, 0xd1, 0xdb, 0xd9, 0x20, 0x52, 0x23)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CUOMapCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DUOMap =
		{ 0x2b360722, 0xf116, 0x4004, { 0xa7, 0x1a, 0x5e, 0x14, 0xb4, 0xc4, 0x87, 0x3e } };
const IID BASED_CODE IID_DUOMapEvents =
		{ 0x4498f69d, 0x483b, 0x403e, { 0x9b, 0x1a, 0x29, 0x8b, 0xda, 0xbc, 0x54, 0x73 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwUOMapOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_IGNOREACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CUOMapCtrl, IDS_UOMAP, _dwUOMapOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl::CUOMapCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CUOMapCtrl

BOOL CUOMapCtrl::CUOMapCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegInsertable | afxRegApartmentThreading to afxRegInsertable.

	if (bRegister)
	{
		HRESULT hr = S_OK;
		//Register as safe for scripting
		hr = CreateComponentCategory(CATID_SafeForScripting, L"Controls that are safely scriptable");
		//if ( FAILED(hr))
		//	return FALSE;
		hr = RegisterCLSIDInCategory(m_clsid, CATID_SafeForScripting);
		//if ( FAILED(hr))
		//	return FALSE;
		// Register as safe for initializing
		hr = CreateComponentCategory(CATID_SafeForInitializing, L"Controls safely initializable from persistent data");
		//if ( FAILED(hr))
		//	return FALSE;
		hr = RegisterCLSIDInCategory(m_clsid, CATID_SafeForInitializing);
		//if ( FAILED(hr))
		//	return FALSE;
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_UOMAP,
			IDB_UOMAP,
			afxRegInsertable | afxRegApartmentThreading,
			_dwUOMapOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	}
	else
	{
		HRESULT hr = S_OK;
		hr = UnRegisterCLSIDInCategory(m_clsid, CATID_SafeForScripting);
		//if ( FAILED(hr))
		//	return FALSE;
		hr = UnRegisterCLSIDInCategory(m_clsid, CATID_SafeForInitializing);
		//if ( FAILED(hr))
		//	return FALSE;
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl::CUOMapCtrl - Constructor

CUOMapCtrl::CUOMapCtrl()
{
	InitializeIIDs(&IID_DUOMap, &IID_DUOMapEvents);

	m_lReadyState = READYSTATE_LOADING;
	// TODO: Call InternalSetReadyState when the readystate changes.

	m_xCenter = UO_X_CENTER;
	m_yCenter = UO_Y_CENTER;
	m_zoomLevel = 0;
	m_dwColorMap = new DWORD[65536];
	m_bDrawStatics = false;
	m_bIsValid = false;
	
	SetModifiedFlag();
	LoadRadarcol();
	InitializeMulPaths();

	m_mulfile = 0;
	m_maxX = 6144;
	m_maxY = 4096;
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl::~CUOMapCtrl - Destructor

CUOMapCtrl::~CUOMapCtrl()
{
	for ( int i = 0; i < m_aDrawObjects.GetSize(); i++ )
	{
		CDrawObject * pObject = (CDrawObject *) m_aDrawObjects.GetAt(i);
		if ( pObject )
			delete pObject;
	}
	m_aDrawObjects.RemoveAll();
	for ( i = 0; i < m_aDrawRects.GetSize(); i++ )
	{
		CDrawRect * pRect =(CDrawRect *) m_aDrawRects.GetAt(i);
		if ( pRect )
			delete pRect;
	}
	m_aDrawRects.RemoveAll();
	delete [] m_dwColorMap;
	CleanHashArray(m_aMap0Hash);
	CleanHashArray(m_aMap1Hash);
	CleanHashArray(m_aMap2Hash);
	CleanHashArray(m_aStatic0Hash);
	CleanHashArray(m_aStatic1Hash);
	CleanHashArray(m_aStatic2Hash);
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl::OnDraw - Drawing function

void CUOMapCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	if ( rcBounds.Width() != m_rcSize.Width() || rcBounds.Height() != m_rcSize.Height() )
	{
		SetInvalid();
		m_rcSize = rcBounds;
	}
	RedrawMap(pdc, rcBounds, rcInvalid);
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl::DoPropExchange - Persistence support

void CUOMapCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	PX_Bool(pPX, _T("DrawStatics"), m_bDrawStatics, FALSE);
	PX_Short(pPX, _T("xCenter"), m_xCenter, UO_X_CENTER);
	PX_Short(pPX, _T("yCenter"), m_yCenter, UO_Y_CENTER);
	PX_Short(pPX, _T("ZoomLevel"), m_zoomLevel, 0);
	PX_Short(pPX, _T("MapFile"), m_mulfile, 0);
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl::GetControlFlags -
// Flags to customize MFC's implementation of ActiveX controls.
//
// For information on using these flags, please see MFC technical note
// #nnn, "Optimizing an ActiveX Control".
DWORD CUOMapCtrl::GetControlFlags()
{
	DWORD dwFlags = COleControl::GetControlFlags();


	// The control can activate without creating a window.
	// TODO: when writing the control's message handlers, avoid using
	//		the m_hWnd member variable without first checking that its
	//		value is non-NULL.
	// dwFlags |= windowlessActivate;

	// The control can receive mouse notifications when inactive.
	// TODO: if you write handlers for WM_SETCURSOR and WM_MOUSEMOVE,
	//		avoid using the m_hWnd member variable without first
	//		checking that its value is non-NULL.
	dwFlags |= pointerInactive;
	return dwFlags;
}


/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl::OnResetState - Reset control to default state

void CUOMapCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}

HRESULT CreateComponentCategory(CATID catid, WCHAR* catDescription)
	{

    ICatRegister* pcr = NULL ;
    HRESULT hr = S_OK ;

    hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
			NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
	if (FAILED(hr))
		return hr;

    // Make sure the HKCR\Component Categories\{..catid...}
    // key is registered
    CATEGORYINFO catinfo;
    catinfo.catid = catid;
    catinfo.lcid = 0x0409 ; // english

	// Make sure the provided description is not too long.
	// Only copy the first 127 characters if it is
	int len = wcslen(catDescription);
	if (len>127)
		len = 127;
    wcsncpy(catinfo.szDescription, catDescription, len);
	// Make sure the description is null terminated
	catinfo.szDescription[len] = '\0';

    hr = pcr->RegisterCategories(1, &catinfo);
	pcr->Release();

	return hr;
	}

HRESULT RegisterCLSIDInCategory(REFCLSID clsid, CATID catid)
	{
// Register your component categories information.
    ICatRegister* pcr = NULL ;
    HRESULT hr = S_OK ;
    hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
			NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
    if (SUCCEEDED(hr))
    {
       // Register this category as being "implemented" by
       // the class.
       CATID rgcatid[1] ;
       rgcatid[0] = catid;
       hr = pcr->RegisterClassImplCategories(clsid, 1, rgcatid);
    }

    if (pcr != NULL)
        pcr->Release();
  
	return hr;
	}

HRESULT UnRegisterCLSIDInCategory(REFCLSID clsid, CATID catid)
	{
    ICatRegister* pcr = NULL ;
    HRESULT hr = S_OK ;
    hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr, 
			NULL, CLSCTX_INPROC_SERVER, IID_ICatRegister, (void**)&pcr);
    if (SUCCEEDED(hr))
    {
       // Unregister this category as being "implemented" by
       // the class.
       CATID rgcatid[1] ;
       rgcatid[0] = catid;
       hr = pcr->UnRegisterClassImplCategories(clsid, 1, rgcatid);
    }

    if (pcr != NULL)
        pcr->Release();
  
	return hr;
	}

/////////////////////////////////////////////////////////////////////////////
// CUOMapCtrl message handlers

short CUOMapCtrl::GetZoomLevel() 
{
	return m_zoomLevel;
}

void CUOMapCtrl::SetZoomLevel(short nNewValue) 
{
	m_zoomLevel = nNewValue;
	if ( m_zoomLevel > 8 )
		m_zoomLevel = 8;
	if ( m_zoomLevel < -4 )
		m_zoomLevel = -4;
	SetInvalid();
}

short CUOMapCtrl::GetXCenter() 
{
	return m_xCenter;
}

void CUOMapCtrl::SetXCenter(short nNewValue) 
{
	if ( m_xCenter == nNewValue )
		return;
	if ( nNewValue >= 0 && nNewValue < UO_X_SIZE )
		m_xCenter = nNewValue;
	else
		return;
	SetInvalid();
}

short CUOMapCtrl::GetYCenter() 
{
	return m_yCenter;
}

void CUOMapCtrl::SetYCenter(short nNewValue) 
{
	if ( m_yCenter == nNewValue )
		return;
	if ( nNewValue >= 0 && nNewValue < UO_Y_SIZE )
		m_yCenter = nNewValue;
	else
		return;
	SetInvalid();
}

void CUOMapCtrl::ZoomIn() 
{
	if ( m_zoomLevel < 8 )
		m_zoomLevel++;
	else
		return;
	SetInvalid();
}

void CUOMapCtrl::ZoomOut() 
{
	if ( m_zoomLevel > -4 )
		m_zoomLevel--;
	else
		return;
	SetInvalid();
}

void CUOMapCtrl::RedrawMap(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	if ( m_mulfile < 0 || m_mulfile > 3 )
		return;
	try
	{
		int RectWidth = rcBounds.Width() - (rcBounds.Width() % 8);
		int RectHeight = rcBounds.Height() - (rcBounds.Height() % 8);
		if ( !m_bIsValid )
		{
			bool bDrawStatics = m_bDrawStatics && (m_zoomLevel >= -1);
			int xc = m_xCenter / 8;
			int yc = m_yCenter / 8;

			CString csMapFileName;
			CString csStaticIdxName;
			CString csStaticFileName;
			CString csMapDifFileName;
			//CString csMapDiflFileName;
			CString csStaDifName;
			CString csStaDifiName;
			//CString csStaDiflName;
			CPtrArray *paMapHash, *paStaticHash;

			switch ( m_mulfile )
			{
			case 0:
				csMapFileName = m_saMulPaths.GetAt(VERFILE_MAP0);
				csStaticIdxName = m_saMulPaths.GetAt(VERFILE_STAIDX0);
				csStaticFileName = m_saMulPaths.GetAt(VERFILE_STATICS0);
				csMapDifFileName = m_saMulPaths.GetAt(VERFILE_MAPDIF0);
				//csMapDiflFileName = m_saMulPaths.GetAt(VERFILE_MAPDIFL0);
				csStaDifName = m_saMulPaths.GetAt(VERFILE_STADIF0);
				csStaDifiName = m_saMulPaths.GetAt(VERFILE_STADIFI0);
				//csStaDiflName = m_saMulPaths.GetAt(VERFILE_STADIFL0);
				paMapHash = &m_aMap0Hash;
				paStaticHash = &m_aStatic0Hash;
				break;
			case 1:
				csMapFileName = m_saMulPaths.GetAt(VERFILE_MAP0);
				csStaticIdxName = m_saMulPaths.GetAt(VERFILE_STAIDX0);
				csStaticFileName = m_saMulPaths.GetAt(VERFILE_STATICS0);
				csMapDifFileName = m_saMulPaths.GetAt(VERFILE_MAPDIF1);
				//csMapDiflFileName = m_saMulPaths.GetAt(VERFILE_MAPDIFL1);
				csStaDifName = m_saMulPaths.GetAt(VERFILE_STADIF1);
				csStaDifiName = m_saMulPaths.GetAt(VERFILE_STADIFI1);
				//csStaDiflName = m_saMulPaths.GetAt(VERFILE_STADIFL1);
				paMapHash = &m_aMap1Hash;
				paStaticHash = &m_aStatic1Hash;
				break;
			case 2:
				csMapFileName = m_saMulPaths.GetAt(VERFILE_MAP2);
				csStaticIdxName = m_saMulPaths.GetAt(VERFILE_STAIDX2);
				csStaticFileName = m_saMulPaths.GetAt(VERFILE_STATICS2);
				csMapDifFileName = m_saMulPaths.GetAt(VERFILE_MAPDIF2);
				//csMapDiflFileName = m_saMulPaths.GetAt(VERFILE_MAPDIFL2);
				csStaDifName = m_saMulPaths.GetAt(VERFILE_STADIF2);
				csStaDifiName = m_saMulPaths.GetAt(VERFILE_STADIFI2);
				//csStaDiflName = m_saMulPaths.GetAt(VERFILE_STADIFL2);
				paMapHash = &m_aMap2Hash;
				paStaticHash = &m_aStatic2Hash;
				break;
			case 3:
				csMapFileName = m_saMulPaths.GetAt(VERFILE_MAP3);
				csStaticIdxName = m_saMulPaths.GetAt(VERFILE_STAIDX3);
				csStaticFileName = m_saMulPaths.GetAt(VERFILE_STATICS3);
				csMapDifFileName = m_saMulPaths.GetAt(VERFILE_MAPDIF3);
				//csMapDiflFileName = m_saMulPaths.GetAt(VERFILE_MAPDIFL3);
				csStaDifName = m_saMulPaths.GetAt(VERFILE_STADIF3);
				csStaDifiName = m_saMulPaths.GetAt(VERFILE_STADIFI3);
				//csStaDiflName = m_saMulPaths.GetAt(VERFILE_STADIFL3);
				paMapHash = &m_aMap3Hash;
				paStaticHash = &m_aStatic3Hash;
				break;
			}

			// mapping the mul files into memory
			HANDLE hMapFile = CreateFile(csMapFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			HANDLE hStaIdxFile = CreateFile(csStaticIdxName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			HANDLE hStaticFile = CreateFile(csStaticFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			HANDLE hMapDifFile = CreateFile(csMapDifFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			//HANDLE hMapDiflFile = CreateFile(csMapDiflFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			HANDLE hStaDifFile = CreateFile(csStaDifName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			HANDLE hStaDifiFile = CreateFile(csStaDifiName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			//HANDLE hStaDiflFile = CreateFile(csStaDiflName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
			// Make sure these handles are valid
			if ( (hMapFile == INVALID_HANDLE_VALUE) || (hStaIdxFile == INVALID_HANDLE_VALUE) || (hStaticFile == INVALID_HANDLE_VALUE) )
			{
				if ( hMapFile != INVALID_HANDLE_VALUE )
					CloseHandle(hMapFile);
				if ( hStaIdxFile != INVALID_HANDLE_VALUE )
					CloseHandle(hStaIdxFile);
				if ( hStaticFile != INVALID_HANDLE_VALUE )
					CloseHandle(hStaticFile);
				if ( hMapDifFile != INVALID_HANDLE_VALUE )
					CloseHandle(hMapDifFile);
				//if ( hMapDiflFile != INVALID_HANDLE_VALUE )
					//CloseHandle(hMapDiflFile);
				if ( hStaDifFile != INVALID_HANDLE_VALUE )
					CloseHandle(hStaDifFile);
				if ( hStaDifiFile != INVALID_HANDLE_VALUE )
					CloseHandle(hStaDifiFile);
				//if ( hStaDiflFile != INVALID_HANDLE_VALUE )
					//CloseHandle(hStaDiflFile);
				return;
			}

			HANDLE hMapFileMapping = CreateFileMapping(hMapFile, NULL, PAGE_READONLY, 0, 0, NULL);
			HANDLE hStaIdxFileMapping = CreateFileMapping(hStaIdxFile, NULL, PAGE_READONLY, 0, 0, NULL);
			HANDLE hStaticFileMapping = CreateFileMapping(hStaticFile, NULL, PAGE_READONLY, 0, 0, NULL);
			HANDLE hMapDifFileMapping = CreateFileMapping(hMapDifFile, NULL, PAGE_READONLY, 0, 0, NULL);
			//HANDLE hMapDiflFileMapping = CreateFileMapping(hMapDiflFile, NULL, PAGE_READONLY, 0, 0, NULL);
			HANDLE hStaDifFileMapping = CreateFileMapping(hStaDifFile, NULL, PAGE_READONLY, 0, 0, NULL);
			HANDLE hStaDifiFileMapping = CreateFileMapping(hStaDifiFile, NULL, PAGE_READONLY, 0, 0, NULL);
			//HANDLE hStaDiflFileMapping = CreateFileMapping(hStaDiflFile, NULL, PAGE_READONLY, 0, 0, NULL);

			PBYTE pbMapFile = (PBYTE) MapViewOfFile(hMapFileMapping, FILE_MAP_READ, 0, 0, 0);
			PBYTE pbStaIdxFile = (PBYTE) MapViewOfFile(hStaIdxFileMapping, FILE_MAP_READ, 0, 0, 0);
			PBYTE pbStaticFile = (PBYTE) MapViewOfFile(hStaticFileMapping, FILE_MAP_READ, 0, 0, 0);
			PBYTE pbMapDifFile = (PBYTE) MapViewOfFile(hMapDifFileMapping, FILE_MAP_READ, 0, 0, 0);
			//PBYTE pbMapDiflFile = (PBYTE) MapViewOfFile(hMapDiflFileMapping, FILE_MAP_READ, 0, 0, 0);
			PBYTE pbStaDifFile = (PBYTE) MapViewOfFile(hStaDifFileMapping, FILE_MAP_READ, 0, 0, 0);
			PBYTE pbStaDifiFile = (PBYTE) MapViewOfFile(hStaDifiFileMapping, FILE_MAP_READ, 0, 0, 0);
			//PBYTE pbStaDiflFile = (PBYTE) MapViewOfFile(hStaDiflFileMapping, FILE_MAP_READ, 0, 0, 0);

			m_bMapArray.RemoveAll();
			m_bMapArray.SetSize(RectWidth * RectHeight * 3);
			int scalefactor;
			if ( m_zoomLevel == -4 )
				scalefactor = 2;	// We can skip alternating blocks
			else
				scalefactor = 1;	// We need to read each block in the range

			// The number of blocks we actually have to read depends on the zoom level.

			int X1, X2, Y1, Y2, wX1, wX2, wY1, wY2;
			// Determine which blocks are at the bounds of the client rectangle
			int iBlockWidth = 0;
			int iBlockHeight = 0;
			int iCellsPerBlock = 8;
			int iPixelsPerCell = 1;
			if ( m_zoomLevel > 0 )
				iPixelsPerCell = (int)pow(2, m_zoomLevel);
			if ( m_zoomLevel < 0 )
				iCellsPerBlock = 8 / ( (int)pow(2, abs(m_zoomLevel)));
			if ( iCellsPerBlock < 1 )
			{
				iCellsPerBlock = 1;
				scalefactor = 2;
			}
			iBlockWidth = (int)(RectWidth * (scalefactor * 1.0/ ( iCellsPerBlock * iPixelsPerCell )));
			iBlockHeight = (int)(RectHeight * (scalefactor * 1.0 / ( iCellsPerBlock * iPixelsPerCell )));

			// Upper left
			wX1 = X1 = xc - iBlockWidth / 2;
			wY1 = Y1 = yc - iBlockHeight / 2;
			// Lower right
			wX2 = X2 = xc + iBlockWidth / 2;
			wY2 = Y2 = yc + iBlockHeight/ 2;

			if ( iBlockWidth )
			{
				if ( X1 > 4 )
					X1 -= 5;
				else
					X1 = 0;
				if ( X2 < UO_X_BLOCKS - 4 )
					X2 += 5;
				else
					X2 = UO_X_BLOCKS;
			}
			if ( iBlockHeight )
			{
				if ( Y1 > 4 )
					Y1 -= 5;
				else
					Y1 = 0;
				if ( Y2 < UO_Y_BLOCKS - 4 )
					Y2 += 5;
				else
					Y2 = UO_Y_BLOCKS;
			}

			if ( X2 == X1 )
				X2++;
			if ( Y2 == Y1 )
				Y2++;

			MapBlock *mbArray;
			mbArray = new MapBlock[Y2 - Y1];

			//dlgProgress.SetRange(0, iWidth);
			DWORD mapPos = 0;
			DWORD staticPos = 0;
			for (int i = X1; i < X2; i+=scalefactor)
			{
				//dlgProgress.SetPos(i - X1);
				memset(mbArray, 0x00, sizeof(MapBlock) * (Y2 - Y1));
				// Seek to the next block that we need to read
				int iNextBlock = (i * UO_Y_BLOCKS) + Y1;
				if ( (iNextBlock >= 0) && (iNextBlock < (UO_X_BLOCKS * UO_Y_BLOCKS) ) )
				{
					// Read the blocks from the default file
					PBYTE pbMapFilePtr = pbMapFile + (sizeof(MapBlock) * iNextBlock);;
					memcpy(&mbArray[0], pbMapFilePtr, sizeof(MapBlock) * (Y2 - Y1));
					// Check to see if any of the blocks in this column are patched
					for ( int p = Y1; p < Y2; p++ )
					{
						int o = p - Y1;
						// Is this a patched block?
						DWORD dwPatchOffset = FindPatch(*paMapHash, iNextBlock + o);
						if ( dwPatchOffset != 0xFFFFFFFF )
						{
							pbMapFilePtr = pbMapDifFile + (sizeof(MapBlock) * dwPatchOffset);
							DWORD dwOffset = (DWORD) &mbArray[0] + (o * sizeof(MapBlock));
							memcpy((void*)dwOffset, (void*)pbMapFilePtr, sizeof(MapBlock));
						}
					}
					for (int j = Y1; j < Y2; j+=scalefactor)
					{
						// Read the statics for this block, if applicable
						StaticData statCells[64];
						memset(&statCells[0], 0x00, (sizeof(StaticData) * 64));
						if ( bDrawStatics )
						{
							PBYTE pbIdx = pbStaIdxFile + (((i * UO_Y_BLOCKS) + j) * sizeof(StaticIdx));
							// cfStaticIdx.Seek(((i * UO_Y_BLOCKS) + j) * sizeof(StaticIdx), CFile::begin);
							StaticIdx index;
							memcpy(&index, pbIdx, sizeof(StaticIdx));
							// Is this block patched?
							DWORD dwPatchOffset = FindPatch(*paStaticHash, (i * UO_Y_BLOCKS) + j);
							bool bPatched = false;
							if ( dwPatchOffset != 0xFFFFFFFF )
							{
								pbIdx = pbStaDifiFile + (dwPatchOffset * sizeof(StaticIdx));
								memcpy(&index, pbIdx, sizeof(StaticIdx));
								bPatched = true;
							}
							//cfStaticIdx.Read(&index, sizeof(index));
							if ( index.dwStart != 0xFFFFFFFF )
							{
								// there are statics here
								int numStatics = index.dwLength / sizeof(StaticData);
								PBYTE pbStatics;
								if ( bPatched )
									pbStatics = pbStaDifFile + (index.dwStart);
								else
									pbStatics = pbStaticFile + (index.dwStart);
								//cfStaticFile.Seek(index.dwStart, CFile::begin);
								StaticData * objects = new StaticData [index.dwLength];
								memcpy(&objects[0], (void*)pbStatics, index.dwLength);
								//cfStaticFile.Read(&objects[0], index.dwLength);
								for ( int m = 0; m < numStatics; m++ )
								{
									//StaticData object;
									//cfStaticFile.Read(&object, sizeof(object));
									// Find out which has the highest z value.
									int statBlock = objects[m].bXoff + (objects[m].bYoff * 8);
									if ( statBlock > 64 )
										continue;
									objects[m].bJunk1 = 0xFF;
									if ( statCells[statBlock].bJunk1 == 0xFF )
									{
										if ( statCells[statBlock].bAlt <= objects[m].bAlt )
											memcpy(&statCells[statBlock], &objects[m], sizeof(StaticData));
									}
									else
										memcpy(&statCells[statBlock], &objects[m], sizeof(StaticData));
								}
								delete [] objects;
							}
						}
						// How much of this block do we need to put into our output array?
						for ( int cx = 0; cx < iCellsPerBlock; cx++ )
						{
							for ( int cy = 0; cy < iCellsPerBlock; cy++ )
							{
								
								int iCellIndex = (cy * 8 / iCellsPerBlock) * 8 + (cx * 8 / iCellsPerBlock); 
								WORD wColor;
								WORD wColorHi = (WORD(mbArray[j - Y1].cells[iCellIndex].bColorHi)) << 8;
								WORD wColorLo = (WORD(mbArray[j - Y1].cells[iCellIndex].bColorLo));
								wColor = wColorHi | wColorLo;
								//m_pdwMapArray[i / scalefactor][j / scalefactor] = dwColorMap(wColor);
								DWORD dwColor = m_dwColorMap[wColor];
								BYTE bRed, bGreen, bBlue;
								if ( bDrawStatics && (statCells[iCellIndex].bJunk1 == 0xFF) && (statCells[iCellIndex].bAlt >= mbArray[j - Y1].cells[iCellIndex].bAltitude) )
								{
									// Read the map block for this guy as well, to make sure that the static is above ground
									WORD wColor, wColorHi, wColorLo;
									wColorHi = (WORD) ((statCells[iCellIndex].bColorHi) << 8);
									wColorLo = (WORD) statCells[iCellIndex].bColorLo;
									wColor = (WORD) wColorHi | wColorLo;
									wColor += 0x4000;
									dwColor = m_dwColorMap[wColor];
								}
								bRed = (BYTE) ((dwColor & 0x00FF0000) >> 16);
								bGreen = (BYTE) ((dwColor & 0x0000FF00) >> 8);
								bBlue = (BYTE) ((dwColor & 0x000000FF));
								// Do we draw the map color, or a static color?
								for ( int px = 0; px < iPixelsPerCell; px++ )
								{
									for ( int py = 0; py < iPixelsPerCell; py++ )
									{
										int X, Y;
										X = ((i - wX1) / scalefactor * iCellsPerBlock * iPixelsPerCell) + (cx * iPixelsPerCell) + px;
										Y = ((j - wY1) / scalefactor * iCellsPerBlock * iPixelsPerCell) + (cy * iPixelsPerCell) + py;
										if ( X >=0 && X < RectWidth && Y >= 0 && Y < RectHeight )
										{
											int iIndex = ( ( ( Y ) * RectWidth ) + ( X ) ) * 3;
											m_bMapArray.SetAt(iIndex, bRed);
											m_bMapArray.SetAt(iIndex + 1, bGreen);
											m_bMapArray.SetAt(iIndex + 2, bBlue);
										}
									}
								}
							}
						}
					}
				}
			}
			delete [] mbArray;
			//cfMapFile.Close();

			UnmapViewOfFile(pbMapFile);
			UnmapViewOfFile(pbStaIdxFile);
			UnmapViewOfFile(pbStaticFile);
			UnmapViewOfFile(pbMapDifFile);
			//UnmapViewOfFile(pbMapDiflFile);
			UnmapViewOfFile(pbStaDifFile);
			UnmapViewOfFile(pbStaDifiFile);
			//UnmapViewOfFile(pbStaDiflFile);

			CloseHandle(hMapFileMapping);
			CloseHandle(hStaIdxFileMapping);
			CloseHandle(hStaticFileMapping);
			CloseHandle(hMapDifFileMapping);
			//CloseHandle(hMapDiflFileMapping);
			CloseHandle(hStaDifFileMapping);
			CloseHandle(hStaDifiFileMapping);
			//CloseHandle(hStaDiflFileMapping);

			CloseHandle(hMapFile);
			CloseHandle(hStaIdxFile);
			CloseHandle(hStaticFile);
			CloseHandle(hMapDifFile);
			//CloseHandle(hMapDiflFile);
			CloseHandle(hStaDifFile);
			CloseHandle(hStaDifiFile);
			//CloseHandle(hStaDiflFile);

			int x1, y1, x2, y2;
			x1 = CtrlToMapX(0);
			y1 = CtrlToMapY(0);
			x2 = CtrlToMapX(rcBounds.Width());
			y2 = CtrlToMapY(rcBounds.Height());
			CRect rcMap(x1, y1, x2, y2);
			// Add the user-defined draw rects
			for ( i = 0; i < m_aDrawRects.GetSize(); i++ )
			{
				CDrawRect * pRect = (CDrawRect *) m_aDrawRects.GetAt(i);
				if ( !pRect || pRect->m_bDrawMode >= DRAW_MODE_QTY)
					continue;
				CPoint ptTL, ptBR;
				ptTL = pRect->m_rect.TopLeft();
				ptBR = pRect->m_rect.BottomRight();
				CRect test;
				if ( test.UnionRect(rcMap, pRect->m_rect) == 0)
					continue;
				BYTE bBlue, bRed, bGreen;
				bRed = (BYTE) ((pRect->m_dwColor & 0x00FF0000) >> 16);
				bGreen = (BYTE) ((pRect->m_dwColor & 0x0000FF00) >> 8);
				bBlue = (BYTE) ((pRect->m_dwColor & 0x000000FF));
				int dx, dy;
				dx = ( ( ptTL.x - (wX1 * 8) ) / scalefactor * iCellsPerBlock / 8 ) * iPixelsPerCell;
				dy = ( ( ptTL.y - (wY1 * 8) ) / scalefactor * iCellsPerBlock / 8 ) * iPixelsPerCell;
				for ( int x = 0; x <= pRect->m_rect.Width() / scalefactor * iCellsPerBlock / 8; x++ )
				{
					for ( int y = 0; y <= pRect->m_rect.Height() / scalefactor * iCellsPerBlock / 8; y++ )
					{
						if ( pRect->m_bDrawMode == DRAW_OUTLINE )
						{
							if ( x == 0 || x == (pRect->m_rect.Width() / scalefactor * iCellsPerBlock / 8 ) || y == 0 || y == (pRect->m_rect.Height() / scalefactor * iCellsPerBlock / 8 ) )
							{
								// This is part of the outline
							}
							else
								continue;
						}
						for ( int px = 0; px < iPixelsPerCell; px++ )
						{
							for ( int py = 0; py < iPixelsPerCell; py++ )
							{
								int XR, YR;
								XR = (x * iPixelsPerCell) + px;
								YR = (y * iPixelsPerCell) + py;
								int XC, YC;
								XC = dx + XR;
								YC = dy + YR;
								if ( XC < 0 || XC >= RectWidth )
									continue;
								if ( YC < 0 || YC >= RectHeight )
									continue;
								int iIndex = ( ( YC * RectWidth ) + XC ) * 3;
								if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
									continue;
								if ( pRect->m_bDrawMode != DRAW_BLEND )
								{
									m_bMapArray.SetAt(iIndex, bRed);
									m_bMapArray.SetAt(iIndex + 1, bGreen);
									m_bMapArray.SetAt(iIndex + 2, bBlue);
								}
								else
								{
									BYTE r, g, b;
									r = m_bMapArray.GetAt(iIndex);
									g = m_bMapArray.GetAt(iIndex + 1);
									b = m_bMapArray.GetAt(iIndex + 2);
									m_bMapArray.SetAt(iIndex, bRed | r);
									m_bMapArray.SetAt(iIndex + 1, bGreen | g);
									m_bMapArray.SetAt(iIndex + 2, bBlue | b);
								}
							}
						}
					}
				}
			}
			// Add the user-defined draw objects
			for ( i = 0; i < m_aDrawObjects.GetSize(); i++ )
			{
				CDrawObject * pObject = (CDrawObject *) m_aDrawObjects.GetAt(i);
				if ( !pObject )
					continue;
				CPoint ptTL, ptBR;
				ptTL.x = pObject->m_pt.x - pObject->m_bSize;
				ptTL.y = pObject->m_pt.y - pObject->m_bSize;
				ptBR.x = pObject->m_pt.x + pObject->m_bSize;
				ptBR.y = pObject->m_pt.y + pObject->m_bSize;
				if ( !rcMap.PtInRect(ptTL) && !rcMap.PtInRect(ptBR) )
					continue;
				BYTE bBlue, bRed, bGreen;
				bRed = (BYTE) ((pObject->m_dwColor & 0x00FF0000) >> 16);
				bGreen = (BYTE) ((pObject->m_dwColor & 0x0000FF00) >> 8);
				bBlue = (BYTE) ((pObject->m_dwColor & 0x000000FF));
				int X, Y;
				X = (pObject->m_pt.x - wX1 * 8) / scalefactor * iPixelsPerCell / ( 8 / iCellsPerBlock);
				Y = (pObject->m_pt.y - wY1 * 8) / scalefactor * iPixelsPerCell / ( 8 / iCellsPerBlock);
				switch ( pObject->m_bDrawType )
				{
				case DRAW_NONE:
					break;
				case DRAW_PLUS:
					{
						for ( int x = -(pObject->m_bSize); x <= pObject->m_bSize; x++ )
						{
							int xp;
							xp = X + x;
							if ( xp > RectWidth )
								continue;
							int iIndex = ( ( ( Y ) * RectWidth ) + ( xp ) ) * 3;
							if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
								continue;
							m_bMapArray.SetAt(iIndex, bRed);
							m_bMapArray.SetAt(iIndex + 1, bGreen);
							m_bMapArray.SetAt(iIndex + 2, bBlue);
						}
						for ( int y = -(pObject->m_bSize); y <= pObject->m_bSize; y++ )
						{
							int yp;
							yp = Y + y;
							if ( X > RectWidth )
								continue;
							int iIndex = ( ( ( yp ) * RectWidth ) + ( X ) ) * 3;
							if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
								continue;
							m_bMapArray.SetAt(iIndex, bRed);
							m_bMapArray.SetAt(iIndex + 1, bGreen);
							m_bMapArray.SetAt(iIndex + 2, bBlue);
						}
					}
					break;
				case DRAW_SQUARE:
					{
						for ( int x = -(pObject->m_bSize); x <= pObject->m_bSize; x++ )
						{
							for ( int y = -(pObject->m_bSize); y <= pObject->m_bSize; y++ )
							{
								int xp, yp;
								xp = X + x;
								yp = Y + y;
								if ( xp > RectWidth )
									continue;
								int iIndex = ( ( ( yp ) * RectWidth ) + ( xp ) ) * 3;
								if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
									continue;
								m_bMapArray.SetAt(iIndex, bRed);
								m_bMapArray.SetAt(iIndex + 1, bGreen);
								m_bMapArray.SetAt(iIndex + 2, bBlue);
							}
						}
					}
					break;
				case DRAW_DIAMOND:
					{
						for ( int x = -(pObject->m_bSize); x <= 0; x++ )
						{
							for ( int y = - ( x + pObject->m_bSize) ; y <= x + pObject->m_bSize; y++ )
							{
								int xp, yp;
								xp = X + x;
								yp = Y + y;
								if ( xp > RectWidth )
									continue;
								int iIndex = ( ( ( yp ) * RectWidth ) + ( xp ) ) * 3;
								if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
									continue;
								m_bMapArray.SetAt(iIndex, bRed);
								m_bMapArray.SetAt(iIndex + 1, bGreen);
								m_bMapArray.SetAt(iIndex + 2, bBlue);
							}
						}
						for ( x = 0; x <= pObject->m_bSize; x++ )
						{
							for ( int y = ( x - pObject->m_bSize) ; y <= (pObject->m_bSize - x); y++ )
							{
								int xp, yp;
								xp = X + x;
								yp = Y + y;
								if ( xp > RectWidth )
									continue;
								int iIndex = ( ( ( yp ) * RectWidth ) + ( xp ) ) * 3;
								if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
									continue;
								m_bMapArray.SetAt(iIndex, bRed);
								m_bMapArray.SetAt(iIndex + 1, bGreen);
								m_bMapArray.SetAt(iIndex + 2, bBlue);
							}
						}
					}
					break;
				case DRAW_DOT:
					{
						int iIndex = ( ( ( Y ) * RectWidth ) + ( X ) ) * 3;
						if ( iIndex < 0 || iIndex > (RectWidth * RectHeight * 3) )
							continue;
						m_bMapArray.SetAt(iIndex, bRed);
						m_bMapArray.SetAt(iIndex + 1, bGreen);
						m_bMapArray.SetAt(iIndex + 2, bBlue);
					}
					break;
				case DRAW_CIRCLE:
					{
						for ( int x = -(pObject->m_bSize); x <= pObject->m_bSize; x++ )
						{
							int s = pObject->m_bSize;
							int yb = (int) sqrt( s * s - (x * x) );
							for ( int y = -yb; y <= yb; y++ )
							{
								int xp, yp;
								xp = X + x;
								yp = Y + y;
								if ( xp > RectWidth )
									continue;
								int iIndex = ( ( ( yp ) * RectWidth ) + ( xp ) ) * 3;
								if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
									continue;
								m_bMapArray.SetAt(iIndex, bRed);
								m_bMapArray.SetAt(iIndex + 1, bGreen);
								m_bMapArray.SetAt(iIndex + 2, bBlue);
							}
						}
					}
					break;
				case DRAW_TRIANGLE:
					{
						for ( int x = -(pObject->m_bSize); x <= 0; x++ )
						{
							for ( int y = (- pObject->m_bSize / 4 * x - pObject->m_bSize); y <= (pObject->m_bSize); y++ )
							{
								int xp, yp;
								xp = X + x;
								yp = Y + y;
								if ( xp > RectWidth )
									continue;
								int iIndex = ( ( ( yp ) * RectWidth ) + ( xp ) ) * 3;
								if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
									continue;
								m_bMapArray.SetAt(iIndex, bRed);
								m_bMapArray.SetAt(iIndex + 1, bGreen);
								m_bMapArray.SetAt(iIndex + 2, bBlue);
							}
						}
						for ( x = 0; x <= pObject->m_bSize; x++ )
						{
							for ( int y =  (pObject->m_bSize / 4 * x - pObject->m_bSize); y <= (pObject->m_bSize); y++ )
							{
								int xp, yp;
								xp = X + x;
								yp = Y + y;
								if ( xp > RectWidth )
									continue;
								int iIndex = ( ( ( yp ) * RectWidth ) + ( xp ) ) * 3;
								if ( iIndex < 0 || iIndex >= (RectWidth * RectHeight * 3) )
									continue;
								m_bMapArray.SetAt(iIndex, bRed);
								m_bMapArray.SetAt(iIndex + 1, bGreen);
								m_bMapArray.SetAt(iIndex + 2, bBlue);
							}
						}
					}
					break;
				default:
					break;
				}
			}
		}

		BITMAPINFO bmi;
		memset( &bmi, 0, sizeof( bmi ));
		bmi.bmiHeader.biSize = sizeof(bmi.bmiHeader);
		bmi.bmiHeader.biHeight = -RectHeight;	// - Top down
		bmi.bmiHeader.biWidth = RectWidth;
		bmi.bmiHeader.biBitCount = 24;	// 1,4,8,24
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biCompression = BI_RGB;	// Not compressed
		bmi.bmiHeader.biSizeImage = 0;
		bmi.bmiHeader.biXPelsPerMeter= 0;
		bmi.bmiHeader.biYPelsPerMeter= 0;
		bmi.bmiHeader.biClrUsed 	 = 0;
		bmi.bmiHeader.biClrImportant = 0;

		int iLines = SetDIBitsToDevice(pdc->GetSafeHdc(), rcBounds.left, rcBounds.top, RectWidth, RectHeight, 0, 0, 0, RectHeight, m_bMapArray.GetData(), &bmi, DIB_RGB_COLORS);
		SetModifiedFlag(FALSE);
		m_bIsValid = true;
		return;
	}
	catch (...)
	{
		//AfxMessageBox(_T("UOMap.ocx caught an exception while trying to draw the map.  You may need to close the application."), MB_OK);
	}
}

void CUOMapCtrl::LoadRadarcol()
{
	CFile cfRadarFile;
	CString csRadarFileName;
	memset(&m_dwColorMap[0], 0, sizeof(m_dwColorMap));
	HKEY hKey;
	LONG lStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Origin Worlds Online\\Ultima Online\\1.0"), 0, KEY_READ, &hKey);
	if (lStatus == ERROR_SUCCESS)
	{
		unsigned char szExePath[MAX_PATH];
		DWORD dwType;
		DWORD dwSize = sizeof(szExePath);
		lStatus = RegQueryValueEx(hKey, _T("ExePath"), 0, &dwType, &szExePath[0], &dwSize);
		if (lStatus == ERROR_SUCCESS)
		{
			m_csUOPath.Format(_T("%s"), szExePath);
			m_csUOPath = m_csUOPath.Left(m_csUOPath.ReverseFind('\\') + 1);
		}
		RegCloseKey(hKey);
	}
	else
	{
		lStatus = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Origin Worlds Online\\Ultima Online Third Dawn\\1.0"), 0, KEY_READ, &hKey);
		if (lStatus == ERROR_SUCCESS)
		{
			unsigned char szExePath[MAX_PATH];
			DWORD dwType;
			DWORD dwSize = sizeof(szExePath);
			lStatus = RegQueryValueEx(hKey, _T("ExePath"), 0, &dwType, &szExePath[0], &dwSize);
			if (lStatus == ERROR_SUCCESS)
			{
				m_csUOPath.Format(_T("%s"), szExePath);
				m_csUOPath = m_csUOPath.Left(m_csUOPath.ReverseFind('\\') + 1);
			}
			RegCloseKey(hKey);
		}
	}
	csRadarFileName.Format(_T("%sradarcol.mul"), m_csUOPath);
	if (cfRadarFile.Open(csRadarFileName, CFile::modeRead | CFile::shareDenyNone))
	{
		WORD wColorArray[65536];
		memset(&wColorArray, 0x00, sizeof(wColorArray));
		cfRadarFile.Read(&wColorArray[0], sizeof(wColorArray));
		cfRadarFile.Close();
		for (long i = 0; i < 65536; i++)
			m_dwColorMap[i] = ScaleColor(wColorArray[i]);
	}
}

DWORD CUOMapCtrl::ScaleColor(WORD wColor)
{
	DWORD dwNewColor;
	
	dwNewColor = ((((((wColor >> 10) & 0x01f) * 0x0ff / 0x01f))
		| (((((wColor >> 5) & 0x01f) * 0x0ff / 0x01f)) << 8)
		| ((((wColor & 0x01f) * 0x0ff / 0x01f)) << 16)));
	return (dwNewColor);
}

void CUOMapCtrl::SetCenter(short x, short y) 
{
	if ( m_xCenter == x && m_yCenter == y )
		return;
	if ( x >= 0 && x < UO_X_SIZE && y >= 0 && y < UO_Y_SIZE )
	{
		m_xCenter = x;
		m_yCenter = y;
		SetInvalid();
	}
}

void CUOMapCtrl::Scroll(short direction, short distance) 
{
	int x, y;
	switch ( direction )
	{
	case SCROLL_E:
	case SCROLL_NE:
	case SCROLL_SE:
		x = distance;
		break;
	case SCROLL_W:
	case SCROLL_NW:
	case SCROLL_SW:
		x = - distance;
		break;
	default:
		x = 0;
	}
	switch (direction)
	{
	case SCROLL_N:
	case SCROLL_NE:
	case SCROLL_NW:
		y = - distance;
		break;
	case SCROLL_S:
	case SCROLL_SE:
	case SCROLL_SW:
		y = distance;
		break;
	default:
		y = 0;
	}
	if ( x == 0 && y == 0 )
		return;
	m_xCenter += x;
	m_yCenter += y;
	if ( m_xCenter < 0 )
		m_xCenter = 0;
	if ( m_xCenter >= UO_X_SIZE )
		m_xCenter = UO_X_SIZE - 1;
	if ( m_yCenter < 0 )
		m_yCenter = 0;
	if ( m_yCenter >= UO_Y_SIZE )
		m_yCenter = UO_Y_SIZE;
	SetInvalid();
}

BOOL CUOMapCtrl::GetDrawStatics() 
{
	return m_bDrawStatics;
}

void CUOMapCtrl::SetDrawStatics(BOOL bNewValue) 
{
	if ( m_bDrawStatics == bNewValue )
		return;
	m_bDrawStatics = bNewValue;
	SetInvalid();
}

void CUOMapCtrl::CtrlToMap(short FAR* x, short FAR* y) 
{
	*x = CtrlToMapX(*x);
	*y = CtrlToMapY(*y);
}

void CUOMapCtrl::MapToCtrl(short FAR* x, short FAR* y) 
{
	*x = MapToCtrlX(*x);
	*y = MapToCtrlY(*y);
}

void CUOMapCtrl::SetInvalid()
{
	SetModifiedFlag();
	m_bIsValid = false;
	InvalidateControl();
}

void CUOMapCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	FireMouseDown(nFlags & MK_LBUTTON, nFlags & MK_SHIFT, point.x, point.y);
	COleControl::OnLButtonDown(nFlags, point);
}

void CUOMapCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	FireMouseUp(nFlags & MK_LBUTTON, nFlags & MK_SHIFT, point.x, point.y);
	COleControl::OnLButtonUp(nFlags, point);
}

void CUOMapCtrl::OnRButtonDown(UINT nFlags, CPoint point) 
{
	FireMouseDown(nFlags & MK_RBUTTON, nFlags & MK_SHIFT, point.x, point.y);
	COleControl::OnRButtonDown(nFlags, point);
}

void CUOMapCtrl::OnRButtonUp(UINT nFlags, CPoint point) 
{
	FireMouseUp(nFlags & MK_RBUTTON, nFlags & MK_SHIFT, point.x, point.y);
	COleControl::OnRButtonUp(nFlags, point);
}

void CUOMapCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	if ( point == m_ptMouse )
		return;
	m_ptMouse = point;
	FireMouseMove(nFlags & (MK_RBUTTON | MK_LBUTTON | MK_MBUTTON), nFlags & MK_SHIFT, point.x, point.y);
	
	COleControl::OnMouseMove(nFlags, point);
}

void CUOMapCtrl::GetCenter(short FAR* x, short FAR* y) 
{
	*x = GetXCenter();
	*y = GetYCenter();
}

short CUOMapCtrl::CtrlToMapX(short x) 
{
	// Convert from the control reference frame to map reference frame
	CRect rcMap;
	if ( m_hWnd != NULL )
		GetClientRect(&rcMap);
	else
		rcMap = m_rcBounds;
	int RectWidth = rcMap.Width() - rcMap.Width() % 8;
	int xc = m_xCenter / 8;
	int scalefactor = 1;
	int iCellsPerBlock = 8;
	int iPixelsPerCell = 1;
	if ( m_zoomLevel > 0 )
		iPixelsPerCell = (int)pow(2, m_zoomLevel);
	if ( m_zoomLevel < 0 )
		iCellsPerBlock = 8 / ( (int)pow(2, abs(m_zoomLevel)));
	if ( iCellsPerBlock < 1 )
	{
		iCellsPerBlock = 1;
		scalefactor = 2;
	}
	int iBlockWidth = (int)(RectWidth * (scalefactor * 1.0/ ( iCellsPerBlock * iPixelsPerCell )));
	int wX1 = xc - iBlockWidth / 2;
	int xOffset = x - rcMap.CenterPoint().x;
	// From the zoom level, we should know how many pixels per cell and cells per block we are using
	int factor = iPixelsPerCell * 8 * scalefactor / iCellsPerBlock;
	if ( m_zoomLevel >= 0 )
		xOffset = x / factor;
	else
		xOffset = x * factor;
	x = wX1 * 8 + xOffset;
	//x = m_xCenter + xOffset;
	return x;
}

short CUOMapCtrl::CtrlToMapY(short y) 
{
	// Convert from the control reference frame to map reference frame
	CRect rcMap;
	if ( m_hWnd != NULL )
		GetClientRect(&rcMap);
	else
		rcMap = m_rcBounds;
	int RectHeight = rcMap.Height() - rcMap.Height() % 8;
	int yc = m_yCenter / 8;
	int scalefactor = 1;
	int iCellsPerBlock = 8;
	int iPixelsPerCell = 1;
	if ( m_zoomLevel > 0 )
		iPixelsPerCell = (int)pow(2, m_zoomLevel);
	if ( m_zoomLevel < 0 )
		iCellsPerBlock = 8 / ( (int)pow(2, abs(m_zoomLevel)));
	if ( iCellsPerBlock < 1 )
	{
		iCellsPerBlock = 1;
		scalefactor = 2;
	}
	int iBlockHeight = (int)(RectHeight * (scalefactor * 1.0 / ( iCellsPerBlock * iPixelsPerCell )));
	int wY1 = yc - iBlockHeight / 2;
	int yOffset = y - rcMap.CenterPoint().y;
	// From the zoom level, we should know how many pixels per cell and cells per block we are using
	int factor = iPixelsPerCell * 8 * scalefactor / iCellsPerBlock;
	if ( m_zoomLevel >= 0 )
		yOffset = y / factor;
	else
		yOffset = y * factor;
	y = wY1 * 8 + yOffset;
	//y = m_yCenter + yOffset;
	return y;
}

short CUOMapCtrl::MapToCtrlX(short x) 
{
	// Convert from map reference frame to control reference frame
	CRect rcMap;
	if ( m_hWnd != NULL )
		GetClientRect(&rcMap);
	else
		rcMap = m_rcBounds;
	GetClientRect(&rcMap);
	int RectWidth = rcMap.Width() - rcMap.Width() % 8;
	int xc = m_xCenter / 8;
	// From the zoom level, we should know how many pixels per cell and cells per block we are using
	int scalefactor = 1;
	int iCellsPerBlock = 8;
	int iPixelsPerCell = 1;
	if ( m_zoomLevel > 0 )
		iPixelsPerCell = (int)pow(2, m_zoomLevel);
	if ( m_zoomLevel < 0 )
		iCellsPerBlock = 8 / ( (int)pow(2, abs(m_zoomLevel)));
	if ( iCellsPerBlock < 1 )
	{
		iCellsPerBlock = 1;
		scalefactor = 2;
	}
	int iBlockWidth = (int)(RectWidth * (scalefactor * 1.0/ ( iCellsPerBlock * iPixelsPerCell )));
	int wX1 = xc - iBlockWidth / 2;
	int xOffset = x - (wX1 * 8);
	int factor = iPixelsPerCell * 8 * scalefactor / iCellsPerBlock;
	if ( m_zoomLevel > 0 )
		xOffset *= factor;
	else if ( m_zoomLevel <= 0 )
		xOffset /= factor;
	return xOffset;
}

short CUOMapCtrl::MapToCtrlY(short y) 
{
	// Convert from map reference frame to control reference frame
	CRect rcMap;
	if ( m_hWnd != NULL )
		GetClientRect(&rcMap);
	else
		rcMap = m_rcBounds;
	GetClientRect(&rcMap);
	int RectHeight = rcMap.Height() - rcMap.Height() % 8;
	int yc = m_yCenter / 8;
	// From the zoom level, we should know how many pixels per cell and cells per block we are using
	int scalefactor = 1;
	int iCellsPerBlock = 8;
	int iPixelsPerCell = 1;
	if ( m_zoomLevel > 0 )
		iPixelsPerCell = (int)pow(2, m_zoomLevel);
	if ( m_zoomLevel < 0 )
		iCellsPerBlock = 8 / ( (int)pow(2, abs(m_zoomLevel)));
	if ( iCellsPerBlock < 1 )
	{
		iCellsPerBlock = 1;
		scalefactor = 2;
	}
	int iBlockHeight = (int)(RectHeight * (scalefactor * 1.0 / ( iCellsPerBlock * iPixelsPerCell )));
	int wY1 = yc - iBlockHeight / 2;
	int yOffset = y - (wY1 * 8);
	int factor = iPixelsPerCell * 8 * scalefactor / iCellsPerBlock;
	if ( m_zoomLevel > 0 )
		yOffset *= factor;
	else if ( m_zoomLevel <= 0 )
		yOffset /= factor;
	return yOffset;
}

short CUOMapCtrl::GetMapHeight(short x, short y) 
{
	int XBlock, YBlock, XCell, YCell;
	XBlock = x / 8;
	YBlock = y / 8;
	XCell = x % 8;
	YCell = y % 8;
	int BlockNumber = (XBlock * UO_Y_BLOCKS) + YBlock;
	int cell = (XCell * 8) + YCell;

	// Is this a patched block?
	CPtrArray * pArray;
	CString sFile;
	switch ( m_mulfile )
	{
	case 0:
		pArray = &m_aMap0Hash;
		sFile = m_saMulPaths[VERFILE_MAPDIF0];
		break;
	case 1:
		pArray = &m_aMap1Hash;
		sFile = m_saMulPaths[VERFILE_MAPDIF1];
		break;
	case 2:
		pArray = &m_aMap2Hash;
		sFile = m_saMulPaths[VERFILE_MAPDIF2];
		break;
	case 3:
		pArray = &m_aMap3Hash;
		sFile = m_saMulPaths[VERFILE_MAPDIF3];
		break;
	}
	DWORD dwIndex = FindPatch(*pArray, (DWORD) BlockNumber);

	if ( dwIndex == 0xFFFFFFFF )
	{
		switch (m_mulfile)
		{
		case 0:
		case 1:
			sFile = m_saMulPaths.GetAt(VERFILE_MAP0);
			break;
		case 2:
			sFile = m_saMulPaths.GetAt(VERFILE_MAP2);
			break;
		case 3:
			sFile = m_saMulPaths.GetAt(VERFILE_MAP3);
			break;
		}
		dwIndex = BlockNumber;
	}

	CFile fMap;
	MapBlock block;

	if ( !fMap.Open(sFile, CFile::modeRead | CFile::typeBinary | CFile::shareDenyNone) )
		return 0;
	fMap.Seek(dwIndex * sizeof(MapBlock), CFile::begin);
	fMap.Read(&block, sizeof(block));
	fMap.Close();
	return (short) block.cells[cell].bAltitude;
}

long CUOMapCtrl::AddDrawObject(short x, short y, short type, short size, long color) 
{
	// Verify that the values are good
	if ( x < 0 || y < 0 || type < 0 || type > 255 || size < 0 || size > 255 || color < 0 || color > 0x00FFFFFF )
		return -1;
	CDrawObject * pObject = new CDrawObject;
	pObject->m_pt.x = x;
	pObject->m_pt.y = y;
	pObject->m_bDrawType = (BYTE) type;
	pObject->m_bSize = (BYTE) size;
	pObject->m_dwColor = (DWORD) color;
	int idx = m_aDrawObjects.Add((CObject*) pObject);
	SetInvalid();
	return idx;
}

BOOL CUOMapCtrl::RemoveDrawObject(short x, short y, short type, short size, long color) 
{
	if ( x < 0 || y < 0 || type < 0 || type > 255 || size < 0 || size > 255 || color < 0 || color > 0x00FFFFFF )
		return FALSE;
	for ( int i = 0; i < m_aDrawObjects.GetSize(); i++ )
	{
		CDrawObject * pObject = (CDrawObject *) m_aDrawObjects.GetAt(i);
		if ( !pObject )
			continue;
		if ( pObject->m_pt.x == x && pObject->m_pt.y == y && pObject->m_bSize == (BYTE) size && pObject->m_bDrawType == (BYTE) type && pObject->m_dwColor == (DWORD) color )
		{
			delete pObject;
			m_aDrawObjects.RemoveAt(i);
			SetInvalid();
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CUOMapCtrl::RemoveDrawObjectAt(long index) 
{
	if ( index < 0 || index > m_aDrawObjects.GetUpperBound() )
		return FALSE;
	CDrawObject * pObject = (CDrawObject *) m_aDrawObjects.GetAt(index);
	if ( !pObject )
		return FALSE;
	delete pObject;
	m_aDrawObjects.RemoveAt(index);
	SetInvalid();
	return TRUE;
}

void CUOMapCtrl::RemoveDrawObjects() 
{
	for ( int i = 0; i < m_aDrawObjects.GetSize(); i++ )
	{
		CDrawObject * pObject = (CDrawObject *) m_aDrawObjects.GetAt(i);
		if ( pObject )
			delete pObject;
	}
	m_aDrawObjects.RemoveAll();
	SetInvalid();
	return;
}

long CUOMapCtrl::AddDrawRect(short xleft, short ytop, short width, short height, short mode, long color) 
{
	// Validate the data
	if ( xleft < 0 || ytop < 0 || width < 0 || height < 0 || mode < 0 || color < 0 || color > 0x00FFFFFF )
		return -1;
	CDrawRect * pRect = new CDrawRect;
	pRect->m_rect.SetRect(xleft, ytop, xleft + width, ytop + height);
	pRect->m_bDrawMode = (BYTE) mode;
	pRect->m_dwColor = (DWORD) color;
	long index = m_aDrawRects.Add((CObject *) pRect);
	SetInvalid();
	return index;
}

void CUOMapCtrl::RemoveDrawRects() 
{
	for ( int i = 0; i < m_aDrawRects.GetSize(); i++ )
	{
		CDrawRect * pRect = (CDrawRect *) m_aDrawRects.GetAt(i);
		if ( pRect )
			delete pRect;
	}
	m_aDrawRects.RemoveAll();
	SetInvalid();
	return;
}

BOOL CUOMapCtrl::RemoveDrawRectAt(long index) 
{
	if ( index < 0 || index > m_aDrawRects.GetUpperBound() )
		return FALSE;
	CDrawRect * pRect = (CDrawRect *) m_aDrawRects.GetAt(index);
	if ( !pRect )
		return FALSE;
	delete pRect;
	m_aDrawRects.RemoveAt(index);
	SetInvalid();
	return TRUE;
}

BOOL CUOMapCtrl::RemoveDrawRect(short xleft, short ytop, short width, short height, short mode, long color) 
{
	if ( xleft < 0 || ytop < 0 || width < 0 || height < 0 || mode < 0 || color < 0 || color > 0x00FFFFFF )
		return FALSE;
	for (int i = 0; i < m_aDrawRects.GetSize(); i++)
	{
		CDrawRect * pRect = (CDrawRect *) m_aDrawRects.GetAt(i);
		if ( !pRect )
			continue;
		if ( pRect->m_rect.left == xleft && pRect->m_rect.top == ytop && pRect->m_rect.Width() == width && pRect->m_rect.Height() == height
			&& pRect->m_bDrawMode == (BYTE) mode && pRect->m_dwColor == (DWORD) color )
		{
			delete pRect;
			m_aDrawRects.RemoveAt(i);
			SetInvalid();
			return TRUE;
		}
	}
	return FALSE;
}

void CUOMapCtrl::SetClientPath(LPCTSTR pszClientPath) 
{
	m_csUOPath = pszClientPath;
}

long CUOMapCtrl::GetCenterBlock() 
{
	long lBlock = ( m_xCenter / 8 ) * 512 + ( m_yCenter / 8);
	return lBlock;
}

BOOL CUOMapCtrl::SetCustomMulPath(short sFileIndex, LPCTSTR pszFilePath) 
{
	if ( sFileIndex < 0 || sFileIndex > m_saMulPaths.GetUpperBound() || ( sFileIndex >= 0x13 && sFileIndex <=0x1d) )
		return FALSE;	// Invalid index!
	if ( _tcslen(pszFilePath) == 0 )
		return FALSE;	// Invalid filename!
	m_saMulPaths.SetAt(sFileIndex, pszFilePath);
	switch ( sFileIndex )
	{
	case VERFILE_MAPDIFL0:
		LoadPatchHash(pszFilePath, m_aMap0Hash);
		break;
	case VERFILE_MAPDIFL1:
		LoadPatchHash(pszFilePath, m_aMap1Hash);
		break;
	case VERFILE_MAPDIFL2:
		LoadPatchHash(pszFilePath, m_aMap2Hash);
		break;
	case VERFILE_STADIFL0:
		LoadPatchHash(pszFilePath, m_aStatic0Hash);
		break;
	case VERFILE_STADIFL1:
		LoadPatchHash(pszFilePath, m_aStatic1Hash);
		break;
	case VERFILE_STADIFL2:
		LoadPatchHash(pszFilePath, m_aStatic2Hash);
		break;
	case VERFILE_MAPDIFL3:
		LoadPatchHash(pszFilePath, m_aMap3Hash);
		break;
	case VERFILE_STADIFL3:
		LoadPatchHash(pszFilePath, m_aStatic3Hash);
		break;
	}
	return TRUE;
}

BSTR CUOMapCtrl::GetCustomMulPath(short sFileIndex) 
{
	CString strResult;
	if ( sFileIndex < 0 || sFileIndex > m_saMulPaths.GetUpperBound() || ( sFileIndex >= 0x13 && sFileIndex <=0x1d) )
	{
		// Do nothing...we never set these
	}
	else
		strResult = m_saMulPaths.GetAt(sFileIndex);
	return strResult.AllocSysString();
}

void CUOMapCtrl::InitializeMulPaths()
{
	m_saMulPaths.SetSize(VERFILE_ENDOFTABLE);

	CString csPath;

	csPath.Format(_T("%smap0.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAP0, csPath);

	csPath.Format(_T("%sstaidx0.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STAIDX0, csPath);

	csPath.Format(_T("%sstatics0.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STATICS0, csPath);

	csPath.Format(_T("%sartidx.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_ARTIDX, csPath);

	csPath.Format(_T("%sart.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_ART, csPath);

	csPath.Format(_T("%sanim.idx"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_ANIMIDX, csPath);

	csPath.Format(_T("%sanim.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_ANIM, csPath);

	csPath.Format(_T("%ssoundidx.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_SOUNDIDX, csPath);

	csPath.Format(_T("%ssound.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_SOUND, csPath);

	csPath.Format(_T("%stexidx.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_TEXIDX, csPath);

	csPath.Format(_T("%stexmaps.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_TEXMAPS, csPath);

	csPath.Format(_T("%sgumpidx.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_GUMPIDX, csPath);

	csPath.Format(_T("%sgumpart.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_GUMPART, csPath);

	csPath.Format(_T("%smulti.idx"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MULTIIDX, csPath);

	csPath.Format(_T("%smulti.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MULTI, csPath);

	csPath.Format(_T("%sskills.idx"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_SKILLSIDX, csPath);

	csPath.Format(_T("%sskills.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_SKILLS, csPath);

	csPath.Format(_T("%slightidx.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_LIGHTIDX, csPath);

	csPath.Format(_T("%slight.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_LIGHT, csPath);

	csPath.Format(_T("%stiledata.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_TILEDATA, csPath);

	csPath.Format(_T("%sanimdata.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_ANIMDATA, csPath);

	csPath.Format(_T("%shues.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_HUES, csPath);

	csPath.Format(_T("%saniminfo.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_ANIMINFO, csPath);

	csPath.Format(_T("%sfonts.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_FONTS, csPath);

	csPath.Format(_T("%sradarcol.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_RADARCOL, csPath);

	csPath.Format(_T("%sverdata.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_VERDATA, csPath);

	csPath.Format(_T("%smap2.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAP2, csPath);

	csPath.Format(_T("%sstaidx2.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STAIDX2, csPath);

	csPath.Format(_T("%sstatics2.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STATICS2, csPath);

	csPath.Format(_T("%sanim2.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_ANIM2, csPath);

	csPath.Format(_T("%sanim2.idx"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_ANIMIDX2, csPath);

	csPath.Format(_T("%smapdif0.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAPDIF0, csPath);

	csPath.Format(_T("%smapdif1.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAPDIF1, csPath);

	csPath.Format(_T("%smapdif2.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAPDIF2, csPath);

	csPath.Format(_T("%smapdifl0.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAPDIFL0, csPath);

	csPath.Format(_T("%smapdifl1.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAPDIFL1, csPath);

	csPath.Format(_T("%smapdifl2.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAPDIFL2, csPath);

	csPath.Format(_T("%sstadif0.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIF0, csPath);

	csPath.Format(_T("%sstadif1.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIF1, csPath);

	csPath.Format(_T("%sstadif2.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIF2, csPath);

	csPath.Format(_T("%sstadifi0.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIFI0, csPath);

	csPath.Format(_T("%sstadifi1.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIFI1, csPath);

	csPath.Format(_T("%sstadifi2.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIFI2, csPath);

	csPath.Format(_T("%sstadifl0.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIFL0, csPath);

	csPath.Format(_T("%sstadifl1.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIFL1, csPath);

	csPath.Format(_T("%smap3.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAP3, csPath);

	csPath.Format(_T("%sstaidx3.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STAIDX3, csPath);

	csPath.Format(_T("%sstatics3.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STATICS3, csPath);

	csPath.Format(_T("%smapdif3.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAPDIF3, csPath);

	csPath.Format(_T("%smapdifl3.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_MAPDIFL3, csPath);

	csPath.Format(_T("%sstadif3.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIF3, csPath);

	csPath.Format(_T("%sstadifl3.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIFL3, csPath);

	csPath.Format(_T("%sstadifi3.mul"), m_csUOPath);
	m_saMulPaths.SetAt(VERFILE_STADIFI3, csPath);

	LoadPatchHash(m_saMulPaths.GetAt(VERFILE_MAPDIFL0), m_aMap0Hash);
	LoadPatchHash(m_saMulPaths.GetAt(VERFILE_MAPDIFL1), m_aMap1Hash);
	LoadPatchHash(m_saMulPaths.GetAt(VERFILE_MAPDIFL2), m_aMap2Hash);
	LoadPatchHash(m_saMulPaths.GetAt(VERFILE_MAPDIFL3), m_aMap3Hash);
	LoadPatchHash(m_saMulPaths.GetAt(VERFILE_STADIFL0), m_aStatic0Hash);
	LoadPatchHash(m_saMulPaths.GetAt(VERFILE_STADIFL1), m_aStatic1Hash);
	LoadPatchHash(m_saMulPaths.GetAt(VERFILE_STADIFL2), m_aStatic2Hash);
	LoadPatchHash(m_saMulPaths.GetAt(VERFILE_STADIFL3), m_aStatic3Hash);
}

short CUOMapCtrl::GetMapFile() 
{
	return m_mulfile;
}

void CUOMapCtrl::SetMapFile(short mapfile) 
{
	switch ( mapfile )
	{
	case 0:
	case 1:
		m_maxX = 6144;
		m_maxY = 4096;
		break;
	case 2:
		m_maxX = 2304;
		m_maxY = 1600;
		break;
	case 3:
		m_maxX = 2560;
		m_maxY = 2048;
		break;
	default:
		// Don't know about this one yet
		return;
	}
	// Make sure the current coords are within the bounds
	if ( m_xCenter > m_maxX )
		m_xCenter = UO_X_CENTER;
	if ( m_yCenter > m_maxY )
		m_yCenter = UO_Y_CENTER;
	m_mulfile = mapfile;
	SetInvalid();
}

void CUOMapCtrl::LoadPatchHash(CString sFile, CPtrArray &array)
{
	CleanHashArray(array);
	CFile file;
	if ( !file.Open(sFile, CFile::modeRead | CFile::typeBinary | CFile::shareDenyNone) )
		return;
	DWORD i = 0;
	while ( TRUE )
	{
		DWORD dwIndex;
		if ( ! file.Read(&dwIndex, sizeof(DWORD)) )
			break;
		InsertHash(array, dwIndex, i);
		i++;
	}
	file.Close();	
}

void CUOMapCtrl::CleanHashArray(CPtrArray &array)
{
	for ( int i = 0; i < array.GetSize(); i++ )
	{
		PatchHash * pHash = (PatchHash*) array.GetAt(i);
		if ( pHash )
			delete pHash;
	}
	array.RemoveAll();
}

void CUOMapCtrl::InsertHash(CPtrArray &array, DWORD lookup, DWORD index)
{
	PatchHash * pNewHash = new PatchHash;
	pNewHash->dwIndex = index;
	pNewHash->dwLookup = lookup;

	int iLower = 0;
	int iUpper = array.GetUpperBound();
	if ( iUpper == -1 )
	{
		array.InsertAt(0, pNewHash);
		return;
	}
	int iIndex = 0;
	int iCompare = 0;
	while ( iLower <= iUpper )
	{
		iIndex = (iUpper + iLower ) / 2;
		PatchHash * pTest = (PatchHash *) array.GetAt(iIndex);
		if ( pTest->dwLookup > pNewHash->dwLookup )
		{
			iCompare = 0;
			iUpper = iIndex - 1;
		}
		else
		{
			if ( pTest->dwLookup == pNewHash->dwLookup )
			{
				// Who came up with this brilliant scheme?
				delete pTest;
				array.SetAt(iIndex, pNewHash);
				return;
			}
			iCompare = 1;
			iLower = iIndex + 1;
		}
	}
	iIndex += iCompare;
	array.InsertAt(iIndex, (void *) pNewHash);
	return;
}

DWORD CUOMapCtrl::FindPatch(CPtrArray &array, DWORD lookup)
{
	if ( array.GetSize() == 0 )
		return 0xFFFFFFFF;
	int iLower = 0;
	int iUpper = array.GetUpperBound();
	int iIndex = 0;
	while ( iLower <= iUpper )
	{
		iIndex = (iUpper + iLower ) / 2;
		PatchHash * pTest = (PatchHash *) array.GetAt(iIndex);
		if ( pTest->dwLookup == lookup )
			return pTest->dwIndex;
		if ( pTest->dwLookup > lookup )
			iUpper = iIndex - 1;
		else
			iLower = iIndex + 1;
	}
	return 0xFFFFFFFF;
}
