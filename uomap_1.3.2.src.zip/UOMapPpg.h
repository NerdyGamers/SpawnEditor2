/*
 $Id: UOMapPpg.h,v 1.3 2002/05/28 19:13:01 pesterle Exp $

 **********************************************************************
 * Copyright (C) Philip A. Esterle 2000-2002
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 * 
 **********************************************************************

*/

#if !defined(AFX_UOMAPPPG_H__49F0638D_D244_4358_B922_B4080655CF5F__INCLUDED_)
#define AFX_UOMAPPPG_H__49F0638D_D244_4358_B922_B4080655CF5F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// UOMapPpg.h : Declaration of the CUOMapPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CUOMapPropPage : See UOMapPpg.cpp.cpp for implementation.

class CUOMapPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CUOMapPropPage)
	DECLARE_OLECREATE_EX(CUOMapPropPage)

// Constructor
public:
	CUOMapPropPage();

// Dialog Data
	//{{AFX_DATA(CUOMapPropPage)
	enum { IDD = IDD_PROPPAGE_UOMAP };
	BOOL	m_bDrawStatics;
	short	m_xCenter;
	short	m_yCenter;
	short	m_sZoomLevel;
	int		m_iMapfile;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CUOMapPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UOMAPPPG_H__49F0638D_D244_4358_B922_B4080655CF5F__INCLUDED)
