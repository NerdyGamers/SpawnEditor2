//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UOMap.rc
//
#define IDS_UOMAP                       1
#define IDB_UOMAP                       1
#define IDS_UOMAP_PPG                   2
#define IDS_UOMAP_PPG_CAPTION           200
#define IDD_PROPPAGE_UOMAP              200
#define IDC_DRAWSTATICS                 201
#define IDC_MAPX                        202
#define IDC_MAPY                        203
#define IDC_ZOOMLEVEL                   204
#define IDC_MAPFILE                     205

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
